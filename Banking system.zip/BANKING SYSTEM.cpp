#include <iostream>
#include<string>
using namespace std;


struct date{
    int day,month,year;
    
    
    
  };


int main() {
 long long  int accountNumber;
 long long int accountNumberInput;
  double mainAmount;
  double depoAmount;
  double withAmount;
  double initialAmount;
  string firstName;
  string firstNameInput;
  string lastName;
  string lastNameInput;
  int select;

do {
   cout<<" WELCOM TO OG BANKING SYSTEM  "<<endl;
   cout<<"1. Open Account"<<endl;
   cout<<"2. Deposit"<<endl;
   cout<< "3. Withdraw"<<endl;
   cout<< "4.Generate Account Statement"<<endl;
   cout<< "5. Exit"<<endl;
   cout<< "Enter your Choice\n"<<endl;
   cin>>select;
   
   
   
   switch(select){
     case 1:
       cout<<"Enter First name "<<endl;
       cin>>firstNameInput;
       cout<<"Enter Surname"<<endl;
       cin>>lastNameInput;
       date dob; 
        cout << "Enter Date of Birth (day month year): "<< endl;
        cin >> dob.day;
		cin >> dob.month;
		cin >> dob.year;
        cout<< "Enter Account Number"<<endl;
        cin>> accountNumberInput;
       cout<< "Enter Initial Balance"<<endl;
       cin>>initialAmount;
        mainAmount = initialAmount;
       cout<< "Account opened successfully!\n"<<endl;
       break;
     
     case 2:
       cout<<"Enter First name "<<endl;
       cin>>firstName;
       cout<<"Enter Surname"<<endl;
       cin>>lastName;
       cout<<"Enter Account Number"<<endl;
       cin>>accountNumber;
       if(firstName==firstNameInput&& lastName==lastNameInput &&accountNumber==accountNumberInput){
         cout<<"Enter Amount to Deposit"<<endl;
         cin>>depoAmount;
         cout<<"Deposit successful!"<<endl;
         cout<<"You have deposited "<<depoAmount<< " GH into your account"<<endl;
       }
       else{
         cout<< "Account Not Found\n"<<endl;
       }
       break;
   
     case 3:
         cout<<"Enter First name "<<endl;
       cin>>firstName;
       cout<<"Enter Surname"<<endl;
       cin>>lastName;
       cout<<"Enter Account Number"<<endl;
       cin>>accountNumber;
       if(firstName==firstNameInput && lastName==lastNameInput &&accountNumber==accountNumberInput){
         cout<<"Enter Amount to Withdraw"<<endl;
         cin>>withAmount;
         if(withAmount<mainAmount){
           cout<<"You have Withdrawn  "<< withAmount<<" GH from your account\n";
         }
         else if(withAmount>mainAmount){
         cout<< "You dont have enough money to withdraw\n"<<endl;
       }
        else{
        	cout<<"Acount not Found\n"<<endl;
		}
       break;
  case 4:
    cout<<"Enter First name "<<endl;
       cin>>firstName;
       cout<<"Enter Surname"<<endl;
       cin>>lastName;
       cout<<"Enter Account Number"<<endl;
       cin>>accountNumber;
       if(firstName==firstName&& lastName==lastName &&accountNumber==accountNumber){
         cout<<"Account Statement for Account Number "<<accountNumber<<endl;
         cout<<"Name:"<<lastName<<""<<firstName<<endl;
         cout << "Balance GH" << (initialAmount + depoAmount - withAmount);
         cout<< "\n";
       }
       else{
         cout<< "Account Not Found\n"<<endl;
       }
       break;
       
  case 5:
       cout<< "Exiting the Program"<< endl;
     return 0;
     
     
     default:
       cout<< "Invalid Choice\n"<<endl;
       break;
 
    }

  }
  }while (select!=5);
return 0;
}
